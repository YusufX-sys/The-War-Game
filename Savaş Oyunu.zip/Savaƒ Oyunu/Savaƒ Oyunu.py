from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random
import time
app = Ursina()
application.target_frame_rate = 60
paralar = 0
kill = 0
dusmanlar = []
oyuncu_cani = 100
dusman_vurus_zamani = {}
mermi = 25
kutular = []
zoom_hizi = 2
min_fov = 20
max_fov = 70
can_bloklari = []
sarjor_izni = False
sarjor = Text(text=f"{mermi}/∞", position=(-0.8, -0.45), scale=2, color=color.white, background=True, origin=(0,0), background_color=color.black)
para_yazi = Text(text=f"Para: {paralar}", position=(-0.8, 0.45), scale=2, color=color.white, background=True, origin=(0,0), background_color=color.black)
can_yazi = Text(text=f"Can: {oyuncu_cani}", position=(-0.78, 0.3), scale=2, color=color.white, background=True, origin=(0,0), background_color=color.black)
kill_yazi = Text(text=f"Kills: {kill}", position=(-0.55, 0.45), scale=2, color=color.white, background=True, origin=(0,0), background_color=color.black)
ground = Entity(model='cube', scale=(400,1,400), texture="grass", collider="box")
wall1 = Entity(model='cube', scale=(1,50,400), position=(200,1.5,0), color=color.gray, collider="box", texture="brick")
wall2 = Entity(model='cube', scale=(1,50,400), position=(-200,1.5,0), color=color.gray, collider="box", texture="brick")
wall3 = Entity(model='cube', scale=(400,50,1), position=(0,1.5,200), color=color.gray, collider="box", texture="brick")
wall4 = Entity(model='cube', scale=(400,50,1), position=(0,1.5,-200), color=color.gray, collider="box", texture="brick")
for _ in range(300):
    duvar_konumlari_x = random.randint(-200, 200)
    duvar_konumlari_z = random.randint(-200, 200)
    duvarlar = Entity(model="cube", scale=(1,25,10), position=(duvar_konumlari_x, -0.5, duvar_konumlari_z), collider="box", texture="brick", rotation=(0, random.choice([0, 90]), 0))
for _ in range(20):
    blok_x = random.randint(-200, 200)
    blok_z = random.randint(-200, 200)
    rastgele_blok = Entity(model="cube", position=(blok_x, 1.5, blok_z), collider="box", texture="kutu_texture.jpg", scale=(1, 2, 1))
    kutular.append(rastgele_blok)
for _ in range(20):
    can_blok_x = random.randint(-200, 200)
    can_blok_z = random.randint(-200, 200)
    can_blok = Entity(model="cube", scale=(1, 2, 1), position=(can_blok_x, 1.5, can_blok_z), collider="box", texture="can_blok.png")
    can_bloklari.append(can_blok)
player = FirstPersonController(y=2)
player.scale_y = 2
player.collider = "box"
player.speed = 15
silah = Entity(model="cube", scale=(0.2, 0.2, 0.7), position=(0.2, -0.2, 0.5), parent=camera, color=color.black)
ates_suresi = 0.2
ates_zamani = 0
hedef_fov = 40
def dusman_spawn():
    rastgele_x = random.randint(-200, 200)
    rastgele_z = random.randint(-200, 200)
    dusman = Entity(model="cube", scale=(2, 6, 2), position=(rastgele_x, 2, rastgele_z), collider="box", color=color.green)
    dusman.health = 100
    dusmanlar.append(dusman)
for _ in range(15):
   dusman_spawn()
def update():
    global ates_zamani
    global oyuncu_cani
    global dusman_cani
    global paralar
    global dusman
    global kill
    global mermi
    global rastgele_blok
    global kutular
    global can_bloklari
    global can_blok
    global sarjor_izni
    if held_keys["right mouse"]:
        camera.fov = lerp(camera.fov, hedef_fov, time.dt * 5)
    else:
        camera.fov = lerp(camera.fov, 80, time.dt * 5)
    if held_keys["left mouse"] and sarjor_izni:
        if ates_zamani >= ates_suresi and sarjor_izni:
            Audio("silah_sesi", loop=False, autoplay=False, volume=0.01).play()
            efekt_boyutu = random.uniform(0.1, 0.3)
            muzzle_flash = Entity(
                model="sphere",
                color=color.yellow,
                scale=efekt_boyutu,
                position=silah.position + Vec3(0, 0, 0.7),
                parent=camera
                )
            mermi -= 1
            sarjor.text = f"{mermi}/∞"
            destroy(muzzle_flash, delay=0.1)
            ates_zamani = 0
            hit_info = raycast(camera.world_position, camera.forward, distance=500, ignore=[player])
            if hit_info.hit and hit_info.entity in dusmanlar:
                e = hit_info.entity
                dist = distance(player.position, e.position)
                if dist <= 30:
                    e.health -= 20
                elif dist <= 60:
                    e.health -= 15
                elif dist > 60:
                    e.health -= 10
                if e.health <= 0:
                    destroy(e)
                    dusmanlar.remove(e)
                    paralar += 5
                    kill += 1
                    kill_yazi.text = f"Kills: {kill}"
                    para_yazi.text = f"Para: {paralar}"
                if len(dusmanlar) < 15:
                    for _ in range(15):
                        dusman_spawn()
    for e in dusmanlar:
        dist = distance(player.position, e.position)
        if dist <= 75:
            e.position += (player.position - e.position).normalized() * time.dt * 10
        else:
            e.x += (random.random()-0.500) * time.dt
            e.z += (random.random()-0.50) * time.dt
    ates_zamani += time.dt
    if mermi <= 0:
        sarjor_izni = False
    elif mermi > 0:
        sarjor_izni = True
    for g in can_bloklari:
        if player.intersects(g).hit and oyuncu_cani == 90:
            oyuncu_cani += 10
            destroy(g)
            can_bloklari.remove(g)
            can_blok_x = random.randint(-200, 200)
            can_blok_z = random.randint(-200, 200)
            can_blok = Entity(model="cube", scale=(1, 2, 1), position=(can_blok_x, 1.5, can_blok_z), collider="box", texture="can_blok.png")
            can_bloklari.append(can_blok)
            can_yazi.text = f"Can: {oyuncu_cani}"
        elif player.intersects(g).hit and oyuncu_cani < 100:
            oyuncu_cani += 20
            destroy(g)
            can_bloklari.remove(g)
            can_blok_x = random.randint(-200, 200)
            can_blok_z = random.randint(-200, 200)
            can_blok = Entity(model="cube", scale=(1, 2, 1), position=(can_blok_x, 1.5, can_blok_z), collider="box", texture="can_blok.png")
            can_bloklari.append(can_blok)
            can_yazi.text = f"Can: {oyuncu_cani}"
    for e in dusmanlar:
        if player.intersects(e).hit:
            if e not in dusman_vurus_zamani or time.time() - dusman_vurus_zamani[e] >= 1:
                oyuncu_cani -= 10
                can_yazi.text = f"Can: {oyuncu_cani}"
                dusman_vurus_zamani[e] = time.time()
    if oyuncu_cani <= 0:
        exit()
def input(key):
    global mermi
    global hedef_fov
    if key == ("escape"):
        exit()
    if key == "r" and mermi < 25:
        mermi = 25
        sarjor.text = f"{mermi}/∞"
    if held_keys["right mouse"]:
        if key == "scroll down":
            hedef_fov += zoom_hizi
            if hedef_fov > max_fov:
                hedef_fov = max_fov
        elif key == "scroll up":
            hedef_fov -= zoom_hizi
            if hedef_fov < min_fov:
                hedef_fov = min_fov
Sky()
app.run()
 
